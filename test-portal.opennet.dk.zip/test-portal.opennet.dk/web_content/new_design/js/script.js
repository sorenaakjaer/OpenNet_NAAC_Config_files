setTimeout(_ => {
    $('.o-page').removeClass('o-page--is-loading');
}, 500)

/*-----------------------------
  Fixed Navigation
-----------------------------*/
$(window).scroll(function (e) {
    var el = $('.o-header')
    if (window.scrollY > 32) {
        if (!el.hasClass('o-header--fixed')) {
            el.addClass('o-header--fixed')
        }
    } else {
        el.removeClass('o-header--fixed')
    }
});

/*-----------------------------
  BURGER MENU
-----------------------------*/

$('.js-menu-toggle').on('click', function () {
    if ($(this).hasClass('active')) {
        closeBurgerMenu()
    } else {
        $('.o-menu__items').addClass('o-menu__items--active')
        $(this).addClass('active')
        $('.o-menu__overlay').addClass('o-menu__overlay--active')
    }
})

function closeBurgerMenu () {
    $('.js-menu-toggle').removeClass('active')
    $('.o-menu__items').removeClass('o-menu__items--active')
    $('.o-menu__overlay').removeClass('o-menu__overlay--active')
}

$('.js-o-menu__overlay').on('click', function () {
    $('.js-menu-toggle').removeClass('active')
    $('.o-menu__items').removeClass('o-menu__items--active')
    $('.o-menu__overlay').removeClass('o-menu__overlay--active')
})

$('.js-click-nav__home').on('click', function () {
    $('.o-page').attr('class', 'o-page');
    $('.o-menu__items__inner li').each(function () {
        $(this).removeClass('li--active')
    })
    $(this).addClass('li--active');
    $('.js-page-title').text('Mine sager')
    closeBurgerMenu();
    readCasesFromEtray();
})

$('.js-click-nav__all-cases').on('click', function () {
    if (!$('.o-page').hasClass('o-page--all-cases')) {
        $('.o-page').addClass('o-page--all-cases')
    }
    $('.o-menu__items__inner li').each(function () {
        $(this).removeClass('li--active')
    })
    $(this).addClass('li--active')
    $('.js-page-title').text('Alle sager');
    closeBurgerMenu();
    readCasesFromEtray();
})


/*-----------------------------
  Back to top with progress indicator
-----------------------------*/
var progressPath = document.querySelector('.progress_indicator path');
var pathLength = progressPath.getTotalLength();
progressPath.style.transition = progressPath.style.WebkitTransition = 'none';
progressPath.style.strokeDasharray = pathLength + ' ' + pathLength;
progressPath.style.strokeDashoffset = pathLength;
progressPath.getBoundingClientRect();
progressPath.style.transition = progressPath.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
var updateProgress = function () {
    var scroll = $(window).scrollTop();
    var height = $(document).height() - $(window).height();
    var progress = pathLength - (scroll * pathLength / height);
    progressPath.style.strokeDashoffset = progress;
}
updateProgress();
$(window).on('scroll', updateProgress);
var offset = 250;
var duration = 550;
$(window).on('scroll', function () {
    if ($(this).scrollTop() > offset) {
        $('.progress_indicator').addClass('active-progress');
    } else {
        $('.progress_indicator').removeClass('active-progress');
    }
});
$('.progress_indicator').on('click', function (event) {
    event.preventDefault();
    $('html, body').animate({scrollTop: 0}, duration);
    return false;
});

/* =========================
   APPEND ETRAY TO NEW BODY
 =========================== */
appendEtrayCases();
$('#webform').appendTo('.js-form-create-case');

function appendEtrayCases () {
    $('.ETRAY_LIST_OF_CASES').appendTo('.js-list-of-cases');
    // Change table pagination forn "1/3" to "1 af 3"
    var txt = $('.webform_pagerNumber').text()
    $('.webform_pagerNumber').text(txt.replace('/', ' af '));
}

/* =========================
   CREATE CASE MODAL
 =========================== */

$('.js-btn-create-case').on('click', function () {
    $("#webfield14652").val('1545').change();
    closeBurgerMenu() // If button clicked from menu
    if (!$(this).hasClass('active')) {
        $(this).addClass('active')
        $('.o-bg-overlay').addClass('o-bg-overlay--active');
        $('.js-o-modal__create-case').addClass('o-create-case--active');
        $('body').css('overflow', 'hidden');
    } else {
        closeCreateCase();
    }
})

$('.js-close-o-create-case').on('click', function () {
    closeCreateCase();
})

$('.js-click-on-overlay').on('click', function () {
    closeCreateCase();
    closeCasesModal();
})

function closeCreateCase () {
    $('.js-btn-create-case').removeClass('active');
    $('.o-create-case').removeClass('o-create-case--active');
    $('body').css('overflow', 'initial');
    $('.o-bg-overlay').removeClass('o-bg-overlay--active');
}

$('.js-btn-create-case-cancel').on('click', function () {
    closeCreateCase()
})

/* ========================
   CASES FILTERS
 ========================= */

$('.js-remove-assign-cases > input[type="checkbox"]').on('change', function () {
    $('.ETRAY_CASES_READ__NOT_ASSIGNED > input[type="checkbox"]').prop('checked', $(this).is(':checked'));
    readCasesFromEtray();
})

$('.js-filter').on('click', function () {
    $('.js-filter').each(function () {
        $(this).removeClass('o-filters__filter--active')
    })
    $(this).addClass('o-filters__filter--active')
    var filter = $(this).data('filter')
    $('.ETRAY_LIST_VIEWER_CASES > select').val(filter);
    readCasesFromEtray();
})

function readCasesFromEtray () {
    // scroll to top
    window.scroll(0, 0)
    // set loadbar
    var el = $('.js-o-cases__container');
    if (!el.hasClass('o-cases__container--loading')) {
        el.addClass('o-cases__container--loading');
    }
    // Click submit
    $('.ETRAY_READ_CASES > button').click();
    // wait for callback
    $(document).on('etray::cases_loaded', function () {
        $('.js-o-cases__container').removeClass('o-cases__container--loading');
        appendEtrayCases();
        readAllNotifications();
        readAllNumberOfCases();
    })
}

setInterval(function () {
    console.log('updateCases');
    // updateCasesEveryMinute()
}, (60 * 1000))

/*
function updateCasesEveryMinute () {
    $('.ETRAY_READ_CASES > button').click();
    $(document).on('etray::cases_loaded', function () {
        appendEtrayCases();
        readAllNotifications();
        readAllNumberOfCases();
    })
}

 */

readAllNotifications();

// FILTER: read number notifications for filter
function readAllNotifications () {
    readNotification('open-cases');
    readNotification('sla');
    readNotification('closed-cases');
    readNotification('follow-up');
}

function readNotification (filterName) {
    var val = $('.ETRAY_NOTIFICATIONS__' + filterName + ' > input').val();
    $('.js-filter__' + filterName + '> .js-filter__notifications').text(val);
    if (!val || val < 1) {
        $('.js-filter__' + filterName + '> .js-filter__notifications').hide();
    }
}

readAllNumberOfCases();

function readAllNumberOfCases () {
    var arr = ['open-cases', 'sla', 'closed-cases', 'follow-up']
    for (let i = 0; i < arr.length; i++) {
        readNumberOfCases(arr[i])
    }
}

function readNumberOfCases (filterName) {
    var val = $('.ETRAY_NUMBER_OF_CASES__' + filterName + ' > input').val();
    $('.js-filter__' + filterName + '> .js-filter__number-of-cases').text(val);
}

// FILTER: read number of cases for filter

function addFormEventListeners () {
    // Click on div = click on sibling input checkbox
    $('.Web_InnerControl_RADIOBUTTONS > div > input[type="radio"] + div').click(function () {
        $(this).prev('input[type="radio"]').click()
    });
    $('.Web_MainControl_checkbox > input[type="checkbox"] + .CheckboxLabel').click(function () {
        $(this).prev('input[type="checkbox"]').click()
    });
}

addFormEventListeners();

/* ========================
   Search Query
 ========================= */

$('.js-search-input').keyup(debounce(function () {
    var searchQuery = $(this).val();
    if (searchQuery.length > 0) {
        if (!$(this).hasClass('o-search-cases--active')) {
            $(this).addClass('o-search-cases--active')
        }
    } else {
        $(this).removeClass('o-search-cases--active')
    }
    $('.ETRAY_CASE_SEARCH > input').val(searchQuery);
    readCasesFromEtray();
}, 400))

function debounce (func, wait, immediate) {
    var timeout;
    return function () {
        var context = this, args = arguments;
        var later = function () {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};

$('.js-search-input__clear').on('click', function () {
    $('.js-search-input').val('');
    $('.ETRAY_CASE_SEARCH > input').val('');
    $('.js-search-input').removeClass('o-search-cases--active');
    readCasesFromEtray();
})


/* ========================
   SEE SINGLE CASE
 ========================= */

$('.js-case-element').on('click', function () {
    // Hide body for performance
    if (!$('.js-modal__single-case .o-modal__body').hasClass('o-modal__body--loading')) {
        $('.js-modal__single-case .o-modal__body').addClass('o-modal__body--loading');
    }
    $('.o-bg-overlay').addClass('o-bg-overlay--active');
    $('.o-modal__case').addClass('o-modal--active');
    $('body').css('overflow', 'hidden');
    $(this).clone().attr('id', 'js-case-element__inserted').appendTo('.js-case-insert');
    var caseId = $(this).attr('id')
    readEtrayCase(caseId);
    $(document).on('etray::single-case-loaded', function () {
        $('.o-modal__body').removeClass('o-modal__body--loading');
    })
})

function closeCasesModal () {
    $('.o-bg-overlay').removeClass('o-bg-overlay--active');
    $('.o-modal__case').removeClass('o-modal--active');
    $('#js-case-element__inserted').remove();
    $('body').css('overflow', '');
    // Hide body for performance
    if (!$('.js-modal__single-case .o-modal__body').hasClass('o-modal__body--loading')) {
        $('.js-modal__single-case .o-modal__body').addClass('o-modal__body--loading');
    }
}

$('.js-close-modal').on('click', function () {
    closeCasesModal()
})

function readEtrayCase (id) {
    // SET CASE ID
    $('.ETRAY_READ_CASE_ID > input').val(id);
    // CLICK SUBMIT BUTTON
    $('.ETRAY_READ_CASE > button').click()
    readEtrayCaseComments();
}

OnlyForTestingCallbacks();

function OnlyForTestingCallbacks () {
    // READ CASES
    $('.ETRAY_READ_CASES > button').on('click', function () {
        // CHECK FOR CHECKBOX NOT ASSIGNED
        var notAssigned = $('.ETRAY_CASES_READ__NOT_ASSIGNED > input[type="checkbox"]').val();
        var activeFilter = $('.ETRAY_LIST_VIEWER_CASES > select').val();
        // READ CASES MED FILTRE
        console.log('CLICK::ETRAY_READ_CASES', [activeFilter, notAssigned]);
        setTimeout(function () {
            $(document).trigger('etray::cases_loaded')
        }, 1500)
    })

    // READ CASE
    $('.ETRAY_READ_CASE > button').on('click', function () {
        setTimeout(function () {
            // SET ASSIGNED USER ID
            $('.ETRAY_READ_CASE__ASSIGNED_USER_ID > input').val(2);
            $('.ETRAY_READ_CASE__CATEGORY_ID > input').val(212);
            $('.ETRAY_READ_CASE__USER_FOLLOWS > input').val('true');
            $(document).trigger('etray::single-case-loaded')
        }, 500)
    })
}

/*-----------------------------
  CASE: COMMENTS
-----------------------------*/

function readEtrayCaseComments () {
    if (!$('.o-modal__case__timeline').hasClass('o-modal__case__timeline--loading')) {
        $('.o-modal__case__timeline').addClass('o-modal__case__timeline--loading');
    }
    $('.js-o-modal__case__timeline').prepend($('.ETRAY_CASE_TIMELINE > div'));
    $(document).on('etray::single-case-comments-loaded', function () {
        $('.o-modal__case__timeline').removeClass('o-modal__case__timeline--loading');
    })
    setTimeout(function () {
        $(document).trigger('etray::single-case-comments-loaded')
    }, 1500)
}

$('.js-case-click-add-file').on('click', function () {
    $('.ETRAY_COMMENT_UPLOAD_FILE input[type="file"]').click()

    $('body').on('DOMSubtreeModified', '.ETRAY_COMMENT_UPLOAD_FILE #uploadedPanel', function () {
        $('.js-case-click-add-file').html($(this))
    });
})

$('.js-case__save-commentary').on('click', function () {
    if (!$(this).hasClass('o-btn--loading')) {
        $(this).addClass('o-btn--loading');
    }
    readEtrayCaseComments();
    var self = $(this)
    setTimeout(function () {
        $('.o-modal__case__commentary__textarea').val('')
        self.removeClass('o-btn--loading');
    }, 1500)
})

/*-----------------------------
  CASE: Upload file
-----------------------------*/

var $form = $('.js-case-drop-files')
var droppedFiles = false;

$('body').on('drag dragstart dragend dragover dragenter dragleave drop', function (e) {
    e.preventDefault();
    e.stopPropagation();
}).on('dragover dragenter', function () {
    $form.addClass('is-dragover');
}).on('dragleave dragend drop', function () {
    $form.removeClass('is-dragover');
}).on('drop', function (e) {
    droppedFiles = e.originalEvent.dataTransfer.files;
    console.log('droppedFiles', droppedFiles)
});

$form.on('drag dragstart dragend dragover dragenter dragleave drop', function (e) {
    e.preventDefault();
    e.stopPropagation();
}).on('dragover dragenter', function () {
    $form.addClass('is-dragover-element');
}).on('dragleave dragend drop', function () {
    $form.removeClass('is-dragover-element');
}).on('drop', function (e) {
    droppedFiles = e.originalEvent.dataTransfer.files;
    console.log('droppedFiles', droppedFiles)
});

/*-----------------------------
  ASSIGN CASE
-----------------------------*/

$('.js-case-click-assign-case').on('click', function () {
    openSmallModal('js-o-modal--small__assign-case');
    var selectedUserID = $('.ETRAY_READ_CASE__ASSIGNED_USER_ID > input').val()
    if (selectedUserID) {
        oSelectPreselect('js-o-modal--small__assign-case', selectedUserID);
    }
    setTimeout(function () {
        if (!$('.o-select').hasClass('o-select--item-selected')) {
            $('.o-search-input').focus()
        }
    }, 250);
})

$('.ETRAY_LIST_OF_USERS > p').each(function () {
    let value = $(this).attr('id')
    let name = $(this).text()
    $('.js-o-modal--small__assign-case .js-o-select-items').append('<li id="' + value + '">' + name + '</a></li>')
})

$('.js-close-modal-small').on('click', function () {
    closeSmallModal();
    closeOSelect();
})

$('.js-click-modal-small-cancel').on('click', function () {
    closeSmallModal();
    closeOSelect();
})

function openSmallModal (cls) {
    var el = $('.' + cls)
    if (!$(el).hasClass('o-modal--small--active')) {
        $(el).addClass('o-modal--small--active');
        $(el).find('.js-o-modal-small__inner').css('display', 'block')
    }
    if (!$('.o-bg-small-modal-overlay').hasClass('o-bg-small-modal-overlay--active')) {
        $('.o-bg-small-modal-overlay').addClass('o-bg-small-modal-overlay--active')
    }
    oSelect()
}

function closeSmallModal () {
    $('.o-modal--small').removeClass('o-modal--small--active');
    $('.o-bg-small-modal-overlay').removeClass('o-bg-small-modal-overlay--active');
    $('.o-modal--small').find('.js-o-modal-small__inner').css('display', 'block');
    $('.datetimepicker').val('')
}

$('.js-case-assign-case-save').on('click', function () {
    var itemId = $('.js-o-modal--small__assign-case .js-o-select-selected-item-id').val();
    var comment = $('.js-o-modal--small__assign-case .o-modal__case__commentary__textarea').val();
    $('.ETRAY_READ_CASE__ASSIGNED_USER_TEXTAREA > textarea').val(comment);
    $('.ETRAY_READ_CASE__ASSIGNED_USER_ID > input').val(itemId);
    $('.ETRAY_UPDATE_CASE__ASSIGNED_USER_ID').click();
    closeSmallModal('js-o-modal--small__assign-case');
    closeOSelect();
    readEtrayCaseComments();
    // Clean up textarea
    setTimeout(function () {
        $('.o-modal__case__commentary__textarea').val('');
        $('.ETRAY_READ_CASE__ASSIGNED_USER_TEXTAREA > textarea').val('');
    }, 0)
})

/*-----------------------------
  O-SELECT
-----------------------------*/

function oSelectPreselect (parentCls, itemId) {
    var itemName = $('.' + parentCls + ' .o-select__dropdown li#' + itemId).text();
    $('.' + parentCls).find('.o-select__container').find('.js-o-select-selected-item-name').text(itemName)
    $('.' + parentCls).find('.o-select__container').find('.js-o-select-selected-item-id').val(itemId)
    var parentDiv = $('.' + parentCls).find('.o-select')
    if (!parentDiv.hasClass('o-select--item-selected')) {
        parentDiv.addClass('o-select--item-selected');
    }
}

function oSelect () {
    $('.js-o-select-input-lookalike').on('click', function (e) {
        var el = $(this).closest('.o-select');
        if (!el.hasClass('o-select--active')) {
            el.addClass('o-select--active');
        }
        $(this).children('input[type="search"]').focus();
        e.stopPropagation();
    })

    $('.o-modal--small').on('click', function () {
        $('.o-select').removeClass('o-select--active');
        $('input[type="search"]').blur();
        closeOSelect()
    })

    $('.o-select__dropdown ul li').on('click', function () {
        var nameDiv = $(this).closest('.o-select__dropdown').prev('.o-select__container').find('.js-o-select-selected-item-name')
        nameDiv.text($(this).text())
        var idDiv = $(this).closest('.o-select__dropdown').prev('.o-select__container').find('.js-o-select-selected-item-id')
        idDiv.val($(this).attr('id'))
        var parentDiv = $(this).closest('.o-select')
        if (!parentDiv.hasClass('o-select--item-selected')) {
            parentDiv.addClass('o-select--item-selected');
        }
        closeOSelect();
    })

    $('.o-search-input').on('input', function () {
        var el = $(this).closest('.o-select');
        if (!el.hasClass('o-select--active')) {
            el.addClass('o-select--active');
        }
        if ($(this).val().length > 0) {
            console.log($(this).val().length > 0)
            if (!el.hasClass('o-select--searchable')) {
                el.addClass('o-select--searchable');
            }
        } else {
            el.removeClass('o-select--searchable');
        }
    })

    $('.o-select__input').on('keyup', function () {
        var filter = $(this).val().toUpperCase()
        var items = $(this).closest('.o-select__container').siblings('.o-select__dropdown').children('.js-o-select-items').children('li')
        items.each(function () {
            var txtValue = $(this).text()
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                $(this).show()
            } else {
                $(this).hide()
            }
        })
    })

    $('.js-o-select-search-clear').on('click', function () {
        $('.o-search-input').val('');
        $(this).siblings('.js-o-select-selected-item-name').text('')
        $(this).siblings('.js-o-select-selected-item-id').val('')
        $(this).closest('.o-select').removeClass('o-select--item-selected');
    })
}

function closeOSelect () {
    $('.o-select--active').removeClass('o-select--active');
    $('.o-select').removeClass('o-select--searchable');
    $('.o-search-input').val('');
    $('.o-search-input').blur();
    $('.o-items > li').each(function () {
        $(this).css('display', '')
    })
}

/*-----------------------------
  CASE Change category
-----------------------------*/

$('.js-click-case-change-category').on('click', function () {
    openSmallModal('js-o-modal--small__change-category');
    var selectedCategoryID = $('.ETRAY_READ_CASE__CATEGORY_ID > input').val()
    if (selectedCategoryID) {
        oSelectPreselect('js-o-modal--small__change-category', selectedCategoryID);
    }
})

$('.ETRAY_LIST_OF_CATEGORIES > p').each(function () {
    let value = $(this).attr('id')
    let title = $(this).text()
    $('.js-o-modal--small__change-category .js-o-select-items').append('<li id="' + value + '">' + title + '</a></li>')
})

$('.js-case-change-category-save').on('click', function () {
    var itemId = $('.js-o-modal--small__change-category .js-o-select-selected-item-id').val();
    var comment = $('.js-o-modal--small__change-category .o-modal__case__commentary__textarea').val();
    $('.ETRAY_READ_CASE__CATEGORY_ID_TEXTAREA > textarea').val(comment);
    $('.ETRAY_READ_CASE__CATEGORY_ID > input').val(itemId);
    $('.ETRAY_UPDATE_CASE__CATEGORY_ID').click();
    closeSmallModal('js-o-modal--small__change-category');
    closeOSelect();
    readEtrayCaseComments();
    // Clean up textarea
    setTimeout(function () {
        $('.o-modal__case__commentary__textarea').val('');
        $('.ETRAY_READ_CASE__CATEGORY_ID_TEXTAREA > textarea').val('');
    }, 0)
})

/*-----------------------------
  CASE FOLLOW UP
-----------------------------*/

$('.js-click-case-follow-up').on('click', function () {
    openSmallModal('js-o-modal--small__follow-up');
})

$('.js-case-save-follow-up').on('click', function () {
    var datetime = $('.js-o-modal--small__follow-up .datetimepicker').val();
    var comment = $('.js-o-modal--small__follow-up .o-modal__case__commentary__textarea').val();
    $('.ETRAY_READ_CASE__FOLLOW_UP > input').val(datetime);
    $('.ETRAY_READ_CASE__FOLLOW_UP_TEXTAREA > textarea').val(comment);
    $('.ETRAY_UPDATE_CASE__FOLLOW_UP').click();
    closeSmallModal('js-o-modal--small__follow-up');
    readEtrayCaseComments();
    // Clean up textarea
    setTimeout(function () {
        $('.o-modal__case__commentary__textarea').val('');
        $('.ETRAY_READ_CASE__FOLLOW_UP_TEXTAREA > textarea').val('');
    }, 0)
})

/*-----------------------------
  CASE: INTERNAL NOTE
-----------------------------*/

$('.js-click-case-create-note').on('click', function () {
    openSmallModal('js-o-modal--small__create-note');
})

$('.js-case-create-note').on('click', function () {
    var datetime = $('.js-o-modal--small__create-note .datetimepicker').val();
    var comment = $('.js-o-modal--small__create-note .o-modal__case__commentary__textarea').val();
    $('.ETRAY_READ_CASE__INTERNAL_NOTE > input').val(datetime);
    $('.ETRAY_READ_CASE__INTERNAL_NOTE_TEXTAREA > textarea').val(comment);
    $('.ETRAY_UPDATE_CASE__INTERNAL_NOTE').click();
    closeSmallModal('js-o-modal--small__create-note');
    readEtrayCaseComments();
    // Clean up textarea
    setTimeout(function () {
        $('.o-modal__case__commentary__textarea').val('');
        $('.ETRAY_READ_CASE__INTERNAL_NOTE_TEXTAREA > textarea').val('');
    }, 0)
})


/* =================
DATEPICKER
================= */
$('.datetimepicker').datetimepicker('destroy');
$('.datetimepicker').datetimepicker({
    onGenerate: function (ct) {
        jQuery(this).find('.xdsoft_date.xdsoft_day_of_week6')
            .addClass('xdsoft_disabled');
        jQuery(this).find('.xdsoft_date.xdsoft_day_of_week0')
            .addClass('xdsoft_disabled');
        $('.datetimepicker').show();
    },
    lang: 'da',
    dayOfWeekStart: 1,
    minDate: 0,
    inline: true,
    timepicker: true,
    scrollMonth: false,
    scrollInput: false,
    format: 'd.m.Y, H:i',
    defaultTime: '12:00',
    defaultDate: new Date(),
    closeOnDateSelect: true,
    onChangeDateTime: function (dp, $input) {
        console.log(dp, $input)
    }
})


/*-----------------------------
  CASE: USER FOLLOWS
-----------------------------*/
$(document).on('etray::single-case-loaded', function () {
    if ($('.ETRAY_READ_CASE__USER_FOLLOWS > input').val()) {
        if (!$('.js-follow-case').hasClass('js-is-following-case')) {
            $('.js-follow-case').addClass('js-is-following-case')
        }
    }
})

$('.js-follow-case').on('click', function () {
    if (!$(this).hasClass('js-is-following-case')) {
        $(this).addClass('js-is-following-case')
        $('.ETRAY_READ_CASE__USER_FOLLOWS > input').val('true');
    } else {
        $(this).removeClass('js-is-following-case')
        $('.ETRAY_READ_CASE__USER_FOLLOWS > input').val('false');
    }
    $('.ETRAY_UPDATE_CASE__USER_FOLLOWS_UPDATE > button').click();
})

/*-----------------------------
  Automatically resize textarea height to fit text
-----------------------------*/
$(document).ready(function () {
    $('textarea').on('keyup keypress', function () {
        $(this).height(0);
        $(this).height(this.scrollHeight);
    });
});


