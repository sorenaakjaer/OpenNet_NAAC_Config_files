// F� fat i token
var page_token = $('.iframe_token > input').val();
var case_token =  window.location.search.substring(1);
// sammens�t url
;
var url = "https://dev-portal.opennet.dk/eTrayportal/N/Portal/Master.html" + page_token + case_token ;
// �ndre url i iFrame
$('.iframe_fullsize > iframe')[0].src = url
// vis iframe
$('.hidden_iframe').show();